package com.voidx.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class VoidXModsScreen extends Screen {
    private final Screen parent;

    public VoidXModsScreen(Screen parent) {
        super(Text.literal("Mods"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int x = VoidXStyle.centerX(width, 520);
        int y = 76;

        addDrawableChild(ButtonWidget.builder(Text.literal("Back"),
                b -> client.setScreen(parent))
            .dimensions(x, height - 42, 120, 25).build());
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        VoidXStyle.background(ctx, width, height);
        VoidXStyle.header(ctx, width, "MODS");

        int x = VoidXStyle.centerX(width, 520);
        VoidXStyle.panel(ctx, x, 62, 520, height - 116);

        ctx.drawTextWithShadow(textRenderer, Text.literal("VoidX Client"), x + 18, 82, VoidXStyle.WHITE);
        ctx.drawTextWithShadow(textRenderer, Text.literal("Core UI"), x + 18, 103, VoidXStyle.MUTED);
        ctx.drawTextWithShadow(textRenderer, Text.literal("Enabled"), x + 390, 103, VoidXStyle.PURPLE);

        ctx.drawTextWithShadow(textRenderer, Text.literal("Fabric API"), x + 18, 138, VoidXStyle.WHITE);
        ctx.drawTextWithShadow(textRenderer, Text.literal("VoidX GUI"), x + 18, 163, VoidXStyle.WHITE);
        ctx.drawTextWithShadow(textRenderer, Text.literal("HUD System"), x + 18, 188, VoidXStyle.WHITE);

        super.render(ctx, mouseX, mouseY, delta);
    }
}
