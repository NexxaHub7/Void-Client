package com.voidx.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class VoidXOptionsScreen extends Screen {
    private final Screen parent;

    public VoidXOptionsScreen(Screen parent) {
        super(Text.literal("VoidX Options"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int w = 360;
        int x = VoidXStyle.centerX(width, w);
        int y = 78;

        addDrawableChild(ButtonWidget.builder(
                Text.literal("Show FPS: " + (VoidXHudConfig.showFps ? "ON" : "OFF")),
                b -> {
                    VoidXHudConfig.showFps = !VoidXHudConfig.showFps;
                    b.setMessage(Text.literal("Show FPS: " + (VoidXHudConfig.showFps ? "ON" : "OFF")));
                })
            .dimensions(x, y, w, 26).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Back"),
                b -> client.setScreen(parent))
            .dimensions(x, height - 44, 120, 26).build());
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        VoidXStyle.background(ctx, width, height);
        VoidXStyle.header(ctx, width, "HUD / CONFIG");

        int x = VoidXStyle.centerX(width, 520);
        VoidXStyle.panel(ctx, x, 62, 520, height - 118);

        ctx.drawTextWithShadow(textRenderer, Text.literal("HUD"), x + 18, 80, VoidXStyle.WHITE);
        ctx.drawTextWithShadow(textRenderer,
                Text.literal("Configure the information shown while playing."),
                x + 18, 100, VoidXStyle.MUTED);

        ctx.drawTextWithShadow(textRenderer, Text.literal("Performance"), x + 18, 132, VoidXStyle.PURPLE);
        ctx.drawTextWithShadow(textRenderer, Text.literal("FPS counter"), x + 18, 154, VoidXStyle.WHITE);

        super.render(ctx, mouseX, mouseY, delta);
    }
}
