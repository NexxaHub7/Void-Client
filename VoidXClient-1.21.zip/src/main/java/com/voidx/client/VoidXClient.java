package com.voidx.client;

import net.fabricmc.api.ClientModInitializer;

public class VoidXClient implements ClientModInitializer {
    public static final String NAME = "VoidX Client";

    @Override
    public void onInitializeClient() {
        VoidXHud.init();
    }
}
