package com.voidx.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class VoidXTitleScreen extends Screen {
    private final Screen previous;

    public VoidXTitleScreen(Screen previous) {
        super(Text.literal("VoidX"));
        this.previous = previous;
    }

    @Override
    protected void init() {
        int w = 310;
        int x = VoidXStyle.centerX(width, w);
        int y = Math.max(92, height / 2 - 90);

        addDrawableChild(ButtonWidget.builder(Text.literal("Singleplayer"),
                b -> client.setScreen(new net.minecraft.client.gui.screen.world.SelectWorldScreen(this)))
            .dimensions(x, y, w, 25).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Multiplayer"),
                b -> client.setScreen(new net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen(this)))
            .dimensions(x, y + 31, w, 25).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Mods"),
                b -> client.setScreen(new VoidXModsScreen(this)))
            .dimensions(x, y + 62, w, 25).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Options..."),
                b -> client.setScreen(new VoidXOptionsScreen(this)))
            .dimensions(x, y + 98, 152, 25).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Quit Game"),
                b -> client.scheduleStop())
            .dimensions(x + 158, y + 98, 152, 25).build());
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        VoidXStyle.background(ctx, width, height);

        // Intentionally no Minecraft logo: VoidX owns the menu identity.
        VoidXStyle.title(ctx, Text.literal("VOIDX"), width / 2, 48, VoidXStyle.WHITE);
        VoidXStyle.title(ctx, Text.literal("CLIENT"), width / 2, 68, VoidXStyle.PURPLE);

        super.render(ctx, mouseX, mouseY, delta);

        ctx.drawTextWithShadow(textRenderer, Text.literal("1.21 • Fabric"), 10, height - 27, VoidXStyle.MUTED);
        VoidXStyle.footer(ctx, width, height);
    }
}
