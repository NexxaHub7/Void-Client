package com.voidx.client;

import net.minecraft.client.MinecraftClient;

public final class VoidXHudConfig {
    private VoidXHudConfig() {}

    public static boolean showFps = true;

    public static int fps(MinecraftClient client) {
        return client.getCurrentFps();
    }
}
