package com.voidx.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public final class VoidXStyle {
    private VoidXStyle() {}

    public static final int PURPLE = 0xFF9B45FF;
    public static final int PURPLE_DARK = 0xFF5B1CA8;
    public static final int PANEL = 0xCC090711;
    public static final int PANEL_2 = 0xE6120D20;
    public static final int WHITE = 0xFFF4F0FF;
    public static final int MUTED = 0xFFAAA2B8;

    public static void background(DrawContext ctx, int width, int height) {
        ctx.fillGradient(0, 0, width, height, 0xFF09050F, 0xFF14071F);
        // Soft decorative bands; deliberately lightweight for mobile.
        ctx.fill(0, height - 2, width, height, PURPLE);
        ctx.fill(0, 0, width, 1, 0xFF241034);
    }

    public static void panel(DrawContext ctx, int x, int y, int w, int h) {
        ctx.fill(x, y, x + w, y + h, PANEL);
        ctx.fill(x, y, x + 2, y + h, PURPLE);
        ctx.fill(x + w - 2, y, x + w, y + h, PURPLE_DARK);
    }

    public static void title(DrawContext ctx, Text text, int x, int y, int color) {
        ctx.drawCenteredTextWithShadow(
            net.minecraft.client.MinecraftClient.getInstance().textRenderer,
            text, x, y, color
        );
    }

    public static void footer(DrawContext ctx, int width, int height) {
        ctx.drawTextWithShadow(
            net.minecraft.client.MinecraftClient.getInstance().textRenderer,
            Text.literal("VoidX Client  •  Vanilla Feel, Rebuilt"),
            10, height - 14, MUTED
        );
    }

    public static void header(DrawContext ctx, int width, String subtitle) {
        title(ctx, Text.literal("VOIDX"), width / 2, 20, PURPLE);
        title(ctx, Text.literal(subtitle), width / 2, 39, MUTED);
    }

    public static void vanillaButton(DrawContext ctx, int x, int y, int w, int h, boolean hovered) {
        int outer = hovered ? PURPLE : 0xFF3C254D;
        int inner = hovered ? 0xFF241132 : 0xFF100C17;
        ctx.fill(x - 1, y - 1, x + w + 1, y + h + 1, outer);
        ctx.fill(x, y, x + w, y + h, inner);
        ctx.fill(x, y, x + w, y + 1, hovered ? 0xFFD2A4FF : 0xFF4A3C55);
        ctx.fill(x, y + h - 1, x + w, y + h, 0xFF09070D);
    }

    public static void buttonText(DrawContext ctx, Text text, int x, int y, int w, int h, boolean hovered) {
        title(ctx, text, x + w / 2, y + (h - 8) / 2, hovered ? WHITE : 0xFFE2DCE8);
    }

    public static int centerX(int width, int w) {
        return (width - w) / 2;
    }
}
