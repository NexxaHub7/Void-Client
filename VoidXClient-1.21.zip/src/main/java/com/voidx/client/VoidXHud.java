package com.voidx.client;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

public final class VoidXHud {
    private VoidXHud() {}

    public static void init() {
        HudRenderCallback.EVENT.register((ctx, tickDelta) -> render(ctx));
    }

    private static void render(DrawContext ctx) {
        if (!VoidXHudConfig.showFps) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;

        String fps = "FPS: " + mc.getCurrentFps();
        int x = 8;
        int y = 8;
        int w = mc.textRenderer.getWidth(fps) + 18;

        ctx.fill(x - 4, y - 3, x + w, y + 17, 0xB0090710);
        ctx.fill(x - 4, y - 3, x - 2, y + 17, VoidXStyle.PURPLE);
        ctx.drawTextWithShadow(mc.textRenderer, Text.literal(fps), x + 4, y + 2, VoidXStyle.WHITE);
    }
}
