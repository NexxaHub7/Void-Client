package com.voidx.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class VoidXPauseScreen extends Screen {
    private final GameMenuScreen vanilla;

    public VoidXPauseScreen(GameMenuScreen vanilla) {
        super(Text.literal("Game Paused"));
        this.vanilla = vanilla;
    }

    @Override
    protected void init() {
        int w = 330;
        int x = VoidXStyle.centerX(width, w);
        int y = Math.max(74, height / 2 - 85);

        addDrawableChild(ButtonWidget.builder(Text.literal("Back to Game"),
                b -> client.setScreen(null))
            .dimensions(x, y, w, 25).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Advancements"),
                b -> client.setScreen(new net.minecraft.client.gui.screen.advancement.AdvancementsScreen(client.player.networkHandler.getAdvancementHandler())))
            .dimensions(x, y + 31, w, 25).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Statistics"),
                b -> client.setScreen(new net.minecraft.client.gui.screen.StatsScreen(client.player.getStatHandler())))
            .dimensions(x, y + 62, w, 25).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Options..."),
                b -> client.setScreen(new VoidXOptionsScreen(this)))
            .dimensions(x, y + 98, 160, 25).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Save and Quit to Title"),
                b -> client.disconnect())
            .dimensions(x, y + 129, w, 25).build());
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // No custom background: the in-game world remains visible.
        ctx.fill(0, 0, width, height, 0x55000000);

        VoidXStyle.title(ctx, Text.literal("VOIDX"), width / 2, 30, VoidXStyle.WHITE);
        VoidXStyle.title(ctx, Text.literal("GAME PAUSED"), width / 2, 50, VoidXStyle.PURPLE);

        super.render(ctx, mouseX, mouseY, delta);
    }
}
