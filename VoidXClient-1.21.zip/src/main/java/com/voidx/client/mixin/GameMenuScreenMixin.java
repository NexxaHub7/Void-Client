package com.voidx.client.mixin;

import com.voidx.client.VoidXPauseScreen;
import net.minecraft.client.gui.screen.GameMenuScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameMenuScreen.class)
public abstract class GameMenuScreenMixin {
    @Inject(method = "init", at = @At("HEAD"), cancellable = true)
    private void voidx$replacePause(CallbackInfo ci) {
        ci.cancel();
        net.minecraft.client.MinecraftClient.getInstance()
            .setScreen(new VoidXPauseScreen((GameMenuScreen)(Object)this));
    }
}
