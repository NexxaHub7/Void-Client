package com.voidx.client.mixin;

import com.voidx.client.VoidXTitleScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(TitleScreen.class)
public abstract class TitleScreenMixin extends Screen {
    protected TitleScreenMixin(net.minecraft.text.Text title) {
        super(title);
    }

    @Inject(method = "init", at = @At("HEAD"), cancellable = true)
    private void voidx$replaceTitle(CallbackInfo ci) {
        if (this.getClass() == TitleScreen.class) {
            ci.cancel();
            client.setScreen(new VoidXTitleScreen(null));
        }
    }
}
