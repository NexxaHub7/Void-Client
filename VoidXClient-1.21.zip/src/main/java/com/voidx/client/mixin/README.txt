The mixins replace the title and pause screen entry points.
The actual buttons use Minecraft's ButtonWidget so interaction and accessibility
remain vanilla-like while VoidX styling is applied by the client UI layer.
