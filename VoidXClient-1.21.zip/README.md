# VoidX Client — Minecraft 1.21

A client-side UI replacement focused on a polished black/purple VoidX aesthetic.

## Included

- Custom main menu replacing the vanilla title UI.
- Real Minecraft-style interactive buttons:
  - Singleplayer
  - Multiplayer
  - Mods
  - Options...
  - Quit Game
- Custom pause menu opened with Escape.
- Pause screen keeps the world visible underneath; no replacement background image.
- Custom Mods screen.
- Custom VoidX Options/HUD screen.
- Working **Show FPS** toggle and lightweight in-game FPS HUD.
- Lightweight rendering: no shader, blur library, OpenGL hook, or Sodium mixin.

## HUD

`VoidXHudConfig.showFps` is the toggle foundation. The next HUD pass can expose
the toggle in a dedicated VoidX settings screen and draw FPS/coordinates/CPS/etc.

## GitHub build

Push the project to GitHub and run the included workflow:

`.github/workflows/build.yml`

The resulting JAR is uploaded as a GitHub Actions artifact.

## Important

This is a source project intended for Minecraft 1.21 Fabric. Because Minecraft
mappings can change between Yarn builds, compile it through GitHub Actions before
putting the JAR in a launcher. If a mapping error appears, it should be fixed
against the exact Yarn build shown in the Actions log rather than changing the
game version blindly.
